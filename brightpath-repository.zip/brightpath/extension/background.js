const DEFAULT={until:0,minutes:5,enabled:true};
let queue=Promise.resolve();
function serial(fn){const next=queue.then(fn);queue=next.catch(()=>{});return next}
async function reconcile(){const s=await chrome.storage.local.get(DEFAULT);const open=s.enabled===false||s.until>Date.now();const rules=open?[]:[{id:1,priority:1,action:{type:'redirect',redirect:{extensionPath:'/blocked.html'}},condition:{requestDomains:['example.com','chatgpt.com'],resourceTypes:['main_frame']}}];await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:[1],addRules:rules});await chrome.alarms.clear('relock');if(s.enabled&&s.until>Date.now())await chrome.alarms.create('relock',{when:s.until});await chrome.action.setBadgeText({text:open?'OPEN':'LOCK'});await chrome.action.setBadgeBackgroundColor({color:open?'#266653':'#835d30'});return {...s,open}}
chrome.runtime.onInstalled.addListener(()=>serial(async()=>{await chrome.storage.local.set(DEFAULT);return reconcile()}));
chrome.runtime.onStartup.addListener(()=>serial(reconcile));
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='relock')serial(reconcile)});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{if(!sender.url?.startsWith(chrome.runtime.getURL('')))return;serial(async()=>{if(m.type==='unlock'){// Demo quiz validated again in the worker; no website can send this message.
if(m.answer!==1)throw Error('Complete the quiz first.');const s=await chrome.storage.local.get(DEFAULT);await chrome.storage.local.set({until:Date.now()+s.minutes*60000});}
if(m.type==='relock')await chrome.storage.local.set({until:0,enabled:true});
if(m.type==='duration'){if(![1,5,30].includes(m.minutes))throw Error('Invalid duration');await chrome.storage.local.set({minutes:m.minutes,until:0});}
return reconcile()}).then(reply).catch(e=>reply({error:e.message}));return true});
