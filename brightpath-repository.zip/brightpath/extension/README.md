# Brightpath Chrome extension demo

1. Extract the extension ZIP to a folder.
2. In Google Chrome open chrome://extensions.
3. Turn on Developer mode. Click Load unpacked and select the folder containing manifest.json.
4. Pin Brightpath. Its toolbar popup has clearly marked demo parent controls.
5. Choose an unlock duration (1 minute for a short presentation). Click Re-lock.
6. In a NEW tab visit https://example.com or https://chatgpt.com. Chrome should redirect to the bundled mini lesson.
7. Complete the lesson. Try an incorrect answer, then the safe answer.
8. Continue to example.com. New visits are allowed during the unlock period.
9. Re-lock from the toolbar or wait for expiry, then navigate again.

## What is real
Manifest V3 declarativeNetRequest redirects top-level requests to the bundled lesson. Successful completion removes the rule temporarily. A Chrome alarm restores the rule after expiry; startup reconciles stored expiry. Local extension storage holds gate duration and expiry. No hosted website is trusted to unlock the extension. The extension bundles its own module and works without Brightpath hosting or sign-in.

## What is a demo
Controls have no parent authentication and can be changed by anyone. Users can disable/uninstall the extension. Only example.com and chatgpt.com (and subdomains) are gated. Existing pages are not closed or inspected. This is not a content classifier, safe browsing guarantee, app blocker, incognito protector or tamper-proof parental control. There is no synchronisation with website progress or parent settings. Website preview and video show the same lesson UI in simulation mode, not a recording of installed Chrome enforcement.

## Permissions
storage: local settings; alarms: expiry; declarativeNetRequest: rules. Host access is limited to the two demo domains (needed for redirects); no broad all-sites access, history, cookies, page content scripts or analytics. tabs.create is used without sensitive tabs permission. External links only open at user request.

## Verification
JavaScript syntax and mocked Chrome API lifecycle tests run locally, including incorrect answer rejection, unlock, expiry and relock. Installed Chrome enforcement requires the manual checks above; it has not been verified on the user's Chrome profile. Use a separate test profile to avoid interrupting normal browsing.
